
public class TestStaticNestedClass {

	public static void main(String[] args) {
		MyParent.MyChild ob1=new MyParent.MyChild();
        ob1.m1();
	}

}
