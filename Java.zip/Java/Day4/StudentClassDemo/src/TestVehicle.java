import java.util.Date;

public class TestVehicle {

	public static void main(String[] args) {
		Vehicle v1=new Vehicle(12,"Rajan","4 wheeler",new Date());
		System.out.println(v1);
		Vehicle v2=new Vehicle(13,"Atharva","4 wheeler",new Date());
		System.out.println(v2);
	}

}
